<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProductController extends Controller
{
    public static $products = [
        ['id' => '1', 'name' => 'TV', 'description' => 'Best TV', 'price' => 120],
        ['id' => '2', 'name' => 'iPhone', 'description' => 'Best iPhone', 'price' => 999],
        ['id' => '3', 'name' => 'Chromecast', 'description' => 'Best Chromecast', 'price' => 50],
        ['id' => '4', 'name' => 'Glasses', 'description' => 'Best Glasses', 'price' => 75],
    ];

    public function index(): View
    {
        $viewData = [];
        $viewData['title'] = 'Products - Online Store';
        $viewData['subtitle'] = 'List of products';
        $viewData['products'] = ProductController::$products;

        return view('product.index')->with('viewData', $viewData);
    }

    public function show(string $id): View|RedirectResponse
    {
        $viewData = [];
        $product = collect(ProductController::$products)->firstWhere('id', $id);

        if ($product === null) {
            return redirect()->route('home.index');
        }

        $viewData['title'] = $product['name'].' - Online Store';
        $viewData['subtitle'] = $product['name'].' - Product information';
        $viewData['product'] = $product;

        return view('product.show')->with('viewData', $viewData);
    }

    public function create(): View
    {
        $viewData = [];
        $viewData['title'] = 'Create product';

        return view('product.create')->with('viewData', $viewData);
    }

    public function save(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'price' => 'required|numeric|gt:0',
        ]);

        $viewData = [];
        $viewData['title'] = 'Product created';
        $viewData['name'] = $request->input('name');
        $viewData['price'] = $request->input('price');

        return view('product.created')->with('viewData', $viewData);
    }
}
