<?php $__env->startSection('title', $viewData['title']); ?>
<?php $__env->startSection('subtitle', $viewData['subtitle']); ?>

<?php $__env->startSection('content'); ?>
    <div class="card mb-3">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="https://laravel.com/img/logotype.min.svg" class="img-fluid rounded-start">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['card-title', 'text-danger' => $viewData['product']['price'] > 80]); ?>">
                        <?php echo e($viewData['product']['name']); ?>

                    </h5>
                    <p class="card-text"><?php echo e($viewData['product']['description']); ?></p>
                    <p class="card-text">Price: $<?php echo e($viewData['product']['price']); ?></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelcourse\resources\views\product\show.blade.php ENDPATH**/ ?>