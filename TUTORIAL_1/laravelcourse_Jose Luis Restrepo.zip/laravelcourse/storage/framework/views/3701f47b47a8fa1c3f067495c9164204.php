<?php $__env->startSection('title', $viewData['title']); ?>
<?php $__env->startSection('subtitle', 'Product created'); ?>

<?php $__env->startSection('content'); ?>
    <div class="alert alert-success text-center" role="alert">
        <h4 class="alert-heading">Product created successfully!</h4>
        <p class="mb-0">
            <?php echo e($viewData['name']); ?> - $<?php echo e($viewData['price']); ?>

        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelcourse\resources\views/product/created.blade.php ENDPATH**/ ?>