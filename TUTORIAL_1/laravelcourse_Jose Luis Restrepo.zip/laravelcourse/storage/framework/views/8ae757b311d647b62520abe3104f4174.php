<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('subtitle', $subtitle); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 ms-auto">
                <p class="lead"><?php echo e($description); ?></p>
            </div>
            <div class="col-lg-4 me-auto">
                <p class="lead"><?php echo e($author); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelcourse\resources\views\home\about.blade.php ENDPATH**/ ?>