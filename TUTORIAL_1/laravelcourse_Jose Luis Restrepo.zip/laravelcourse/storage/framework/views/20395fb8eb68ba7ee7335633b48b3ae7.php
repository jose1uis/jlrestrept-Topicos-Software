<?php $__env->startSection('title', 'Contact - Online Store'); ?>
<?php $__env->startSection('subtitle', 'Contact'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <p class="lead"><strong>Name:</strong> Your Name</p>
                    <p class="lead"><strong>Address:</strong> Your Address</p>
                    <p class="lead mb-0"><strong>Phone:</strong> Your Phone</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelcourse\resources\views\home\contact.blade.php ENDPATH**/ ?>